package es.ucm.fdi.ici.practica2.demofsm.pacman;

import es.ucm.fdi.ici.fsm.Input;
import pacman.game.Game;

public class MsPacManInput extends Input {

	public MsPacManInput(Game game) {
		super(game);
		
	}

	@Override
	public void parseInput() {
		// does nothing.

	}

}
