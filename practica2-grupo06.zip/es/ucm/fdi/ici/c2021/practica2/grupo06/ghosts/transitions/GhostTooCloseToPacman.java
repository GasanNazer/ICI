package es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions;

import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.GhostsInput;
import es.ucm.fdi.ici.fsm.Input;
import es.ucm.fdi.ici.fsm.Transition;
import pacman.game.Constants.GHOST;

public class GhostTooCloseToPacman implements Transition{
	
	private final static int LIMIT = 30;
	
	GHOST ghost;
	public GhostTooCloseToPacman(GHOST ghost) {
		super();
		this.ghost = ghost;
	}

	@Override
	public boolean evaluate(Input in) {
		GhostsInput input = (GhostsInput) in;
		return input.getDistanceToPacman(ghost) < LIMIT;
	}
	
	@Override
	public String toString() {
		return "Ghost too close to Pacman";
	}
}
