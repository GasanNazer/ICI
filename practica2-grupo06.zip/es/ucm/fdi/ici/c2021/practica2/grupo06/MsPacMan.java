package es.ucm.fdi.ici.c2021.practica2.grupo06;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.MsPacManInput;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.actions.ContinueRunningInTheSameDirection;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.actions.RunAwayFromClosestGhosts;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.actions.RunTowardsNearestGhost;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.actions.RunTowardsPill;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.actions.RunTowardsPowerPill;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.AtLeastOneGhostEdiblePillTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.AtLeastOneGhostEdibleTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.LessTimeToEatGhosts;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.PacManFarFromGhostTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.PacManInJunctionTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.PacManNearGhostAndPowerPillTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.PacManNearGhostTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.PacManNearGhostTransition2;
import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions.PacManNotInJunctionTransition;
import es.ucm.fdi.ici.fsm.CompoundState;
import es.ucm.fdi.ici.fsm.FSM;
import es.ucm.fdi.ici.fsm.Input;
import es.ucm.fdi.ici.fsm.SimpleState;
import es.ucm.fdi.ici.fsm.Transition;
import es.ucm.fdi.ici.fsm.observers.GraphFSMObserver;
import pacman.controllers.PacmanController;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/*
 * The Class NearestPillPacMan.
 */
public class MsPacMan extends PacmanController {

	FSM fsm;
	public MsPacMan() {
    	fsm = new FSM("MsPacMan");
    	
    	//GraphFSMObserver observer = new GraphFSMObserver(fsm.toString());
    	//fsm.addObserver(observer);
    	
    	
    	SimpleState state1 = new SimpleState("Run away from the closest Ghosts", new RunAwayFromClosestGhosts());
    	SimpleState state2 = new SimpleState("Run towards Pill", new RunTowardsPill());
    	SimpleState state3 = new SimpleState("Run towards Power Pill", new RunTowardsPowerPill());
    	SimpleState state4 = new SimpleState("Run towards Ghost(Chasing)", new RunTowardsNearestGhost());
    	
    	//
    	SimpleState state5 = new SimpleState("Continue running in the same direction", new ContinueRunningInTheSameDirection());
    	
    	Transition tran1 = new PacManFarFromGhostTransition();
    	Transition tran2 = new PacManNearGhostTransition();
    	Transition tran3 = new AtLeastOneGhostEdibleTransition();
    	Transition tran4 = new AtLeastOneGhostEdiblePillTransition();
    	Transition tran5 = new LessTimeToEatGhosts();
    	Transition tran6 = new PacManNearGhostTransition2();
    	Transition tran7 = new PacManNearGhostAndPowerPillTransition();
    	
    	//
    	Transition junctionAndGhostNear = new PacManInJunctionTransition();
    	Transition notInJunction = new PacManNotInJunctionTransition();
    	
    	FSM runFSM = new FSM("runMsPacMan");
    	//GraphFSMObserver observer2 = new GraphFSMObserver(fsm.toString());
    	//runFSM.addObserver(observer2);
    	runFSM.add(state1, tran1, state2);
    	runFSM.add(state1, tran2, state3);
    	runFSM.add(state2, tran6, state1);
    	runFSM.add(state2, junctionAndGhostNear, state5);
    	runFSM.add(state5, notInJunction, state3);
    	//runFSM.add(state2, tran7, state3);
    	//fsm.add(state1, tran3, state4);
    	//fsm.add(state2, tran4, state4);
    	//fsm.add(state4, tran5, state1);
    	
    	runFSM.ready(state1);
    	CompoundState run = new CompoundState("run", runFSM);
    	
    	fsm.add(run, tran4, state4);
    	fsm.add(state4, tran5, run);

    	fsm.ready(run);
    	/*
    	JFrame frame = new JFrame();
    	JPanel main = new JPanel();
    	main.setLayout(new BorderLayout());
    	main.add(observer.getAsPanel(true, null), BorderLayout.CENTER);
    	main.add(observer2.getAsPanel(true, null), BorderLayout.SOUTH);
    	frame.getContentPane().add(main);
    	frame.pack();
    	frame.setVisible(true);*/
	}
	
	
	public void preCompute(String opponent) {
    		fsm.reset();
    }
	
	
	
    /* (non-Javadoc)
     * @see pacman.controllers.Controller#getMove(pacman.game.Game, long)
     */
    @Override
    public MOVE getMove(Game game, long timeDue) {
    	Input in = new MsPacManInput(game); 
    	return fsm.run(in);
    }
    
    
}