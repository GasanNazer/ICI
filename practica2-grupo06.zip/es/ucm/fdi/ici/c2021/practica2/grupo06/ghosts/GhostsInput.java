package es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts;

import es.ucm.fdi.ici.fsm.Input;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Game;

public class GhostsInput extends Input {

	private boolean BLINKYedible;
	private boolean INKYedible;
	private boolean PINKYedible;
	private boolean SUEedible;
	private double minPacmanDistancePPill;
	
	public GhostsInput(Game game) {
		super(game);
	}

	@Override
	public void parseInput() {
		this.BLINKYedible = game.isGhostEdible(GHOST.BLINKY);
		this.INKYedible = game.isGhostEdible(GHOST.INKY);
		this.PINKYedible = game.isGhostEdible(GHOST.PINKY);
		this.SUEedible = game.isGhostEdible(GHOST.SUE);
	
		int pacman = game.getPacmanCurrentNodeIndex();
		this.minPacmanDistancePPill = Double.MAX_VALUE;
		for(int ppill: game.getActivePowerPillsIndices()) {
			double distance = game.getDistance(pacman, ppill, DM.PATH);
			this.minPacmanDistancePPill = Math.min(distance, this.minPacmanDistancePPill);
		}
	}

	public boolean isBLINKYedible() {
		return BLINKYedible;
	}

	public boolean isINKYedible() {
		return INKYedible;
	}

	public boolean isPINKYedible() {
		return PINKYedible;
	}

	public boolean isSUEedible() {
		return SUEedible;
	}

	public double getMinPacmanDistancePPill() {
		return minPacmanDistancePPill;
	}

	public int getGhostEdibleTime(GHOST ghost) {
		return game.getGhostEdibleTime(ghost);
	}
	
	public int getDistanceToPacman(GHOST ghost) {
		return game.getShortestPathDistance(game.getGhostCurrentNodeIndex(ghost),
				game.getPacmanCurrentNodeIndex());
	}
	
	public int getDistanceBetweenGhosts(GHOST g1, GHOST g2) {
		return game.getShortestPathDistance(game.getGhostCurrentNodeIndex(g1), game.getGhostCurrentNodeIndex(g2), game.getGhostLastMoveMade(g1));
	}
	
	public boolean isGhostOut(GHOST g) {
		return !(game.getGhostLairTime(g) > 0);
	}
	
}
