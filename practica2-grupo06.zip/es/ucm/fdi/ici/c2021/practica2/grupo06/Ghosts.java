package es.ucm.fdi.ici.c2021.practica2.grupo06;

import java.awt.BorderLayout;
import java.util.EnumMap;

import javax.swing.JFrame;
import javax.swing.JPanel;

import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.GhostsInput;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.actions.ChaseAction;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.actions.GoToPacmanStartingPointAction;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.actions.GoToYourPartOfTheMapAction;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.actions.RunAwayAction;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.actions.StayAwayFromOtherGhostsAction;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.DeadPacmanTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.GhostEndOfEdible;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.GhostTooCloseToPacman;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.GhostsEdibleTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.GhostsNotClose;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.GhostsNotEdibleAndPacManFarPPill;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.GhostsTooCloseToOtherGhost;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.PacManNearPPillTransition;
import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions.PacmanAliveTransition;
import es.ucm.fdi.ici.fsm.CompoundState;
import es.ucm.fdi.ici.fsm.FSM;
import es.ucm.fdi.ici.fsm.SimpleState;
import es.ucm.fdi.ici.fsm.observers.ConsoleFSMObserver;
import es.ucm.fdi.ici.fsm.observers.GraphFSMObserver;
import pacman.controllers.GhostController;
import pacman.game.Game;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class Ghosts extends GhostController {

	private GHOST observeGhost = GHOST.PINKY;
	private GraphFSMObserver observer;
	private GraphFSMObserver observer_run;

	EnumMap<GHOST, FSM> fsms;

	public Ghosts() {
		fsms = new EnumMap<GHOST, FSM>(GHOST.class);
		for (GHOST ghost : GHOST.values()) {
			FSM fsm = new FSM(ghost.name());
			/*
			if(this.observeGhost.equals(ghost)) {
				observer = new GraphFSMObserver(fsm.toString());
		    	fsm.addObserver(observer);
			}
			*/
			
			//fsm.addObserver(new ConsoleFSMObserver(ghost.name()));
			observer = new GraphFSMObserver(ghost.name());
			//fsm.addObserver(observer);
			

			SimpleState chase = new SimpleState("chase", new ChaseAction(ghost));
			SimpleState pacmanDead = new SimpleState("pacmanDead", new GoToPacmanStartingPointAction(ghost));

			FSM run = new FSM("run");
			
			/*if(this.observeGhost.equals(ghost)) {
				this.observer_run = new GraphFSMObserver(fsm.toString());
		    	run.addObserver(observer_run);
			}*/
		
			SimpleState runAway = new SimpleState("runAway", new RunAwayAction(ghost));
			SimpleState stayAway = new SimpleState("stayAway", new StayAwayFromOtherGhostsAction(ghost));
			SimpleState goToCorner = new SimpleState("goToCorner", new GoToYourPartOfTheMapAction(ghost));
			CompoundState runState = new CompoundState("runState", run);

			GhostsEdibleTransition edible = new GhostsEdibleTransition(ghost);
			PacManNearPPillTransition near = new PacManNearPPillTransition();
			GhostsNotEdibleAndPacManFarPPill toChaseTransition = new GhostsNotEdibleAndPacManFarPPill(ghost);
			GhostEndOfEdible endEdible = new GhostEndOfEdible(ghost);
			GhostsTooCloseToOtherGhost tooClose = new GhostsTooCloseToOtherGhost(ghost);
			GhostsNotClose notClose = new GhostsNotClose(ghost);
			GhostTooCloseToPacman closeToPacman = new GhostTooCloseToPacman(ghost);
			DeadPacmanTransition pacmanDies = new DeadPacmanTransition(ghost);
			PacmanAliveTransition pacmanAlive = new PacmanAliveTransition(ghost);

			run.ready(runAway);
			run.add(runAway, tooClose, stayAway);
			run.add(stayAway, notClose, goToCorner);
			run.add(goToCorner, closeToPacman, runAway);
			
			fsm.add(chase, edible, runState);
			fsm.add(chase, near, runState);
			fsm.add(runState, toChaseTransition, chase);
			fsm.add(runState, endEdible, chase);
			fsm.add(chase, pacmanDies, pacmanDead);
			fsm.add(pacmanDead, pacmanAlive, chase);

			
			fsm.ready(chase);

			fsms.put(ghost, fsm);
			/*
			if (observeGhost.equals(ghost)) {
				JFrame frame = new JFrame();
				JPanel main = new JPanel();
				main.setLayout(new BorderLayout());
				main.add(observer.getAsPanel(true, null), BorderLayout.CENTER);
				main.add(observer_run.getAsPanel(true, null), BorderLayout.SOUTH);
				frame.getContentPane().add(main);
				frame.pack();
				frame.setVisible(true);
			}
			*/
		}

	}

	public void preCompute(String opponent) {
		for (FSM fsm : fsms.values())
			fsm.reset();
	}

	@Override
	public EnumMap<GHOST, MOVE> getMove(Game game, long timeDue) {
		EnumMap<GHOST, MOVE> result = new EnumMap<GHOST, MOVE>(GHOST.class);

		GhostsInput in = new GhostsInput(game);

		for (GHOST ghost : GHOST.values()) {
			FSM fsm = fsms.get(ghost);
			MOVE move = fsm.run(in);
			result.put(ghost, move);
		}

		return result;

	}

}
