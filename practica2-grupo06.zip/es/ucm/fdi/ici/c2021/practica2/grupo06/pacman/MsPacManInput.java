package es.ucm.fdi.ici.c2021.practica2.grupo06.pacman;

import es.ucm.fdi.ici.fsm.Input;
import pacman.game.Game;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;

public class MsPacManInput extends Input {
	public static double thresold = 30;
	public static int larger_radius = 80;
	private boolean BLINKYedible;
	private boolean INKYedible;
	private boolean PINKYedible;
	private boolean SUEedible;
	private double minPacmanDistancePPill;
	private GHOST nearestGhost = null;
	private int nearestGhostEdibleTime;
	private boolean PacManInJunction;

	public MsPacManInput(Game game) {
		super(game);
	}

	@Override
	public void parseInput() {
		this.BLINKYedible = game.isGhostEdible(GHOST.BLINKY);
		this.INKYedible = game.isGhostEdible(GHOST.INKY);
		this.PINKYedible = game.isGhostEdible(GHOST.PINKY);
		this.SUEedible = game.isGhostEdible(GHOST.SUE);

		int pacman = game.getPacmanCurrentNodeIndex();
		this.minPacmanDistancePPill = Double.MAX_VALUE;
		for (int ppill : game.getPowerPillIndices()) {
			double distance = game.getDistance(pacman, ppill, DM.PATH);
			this.minPacmanDistancePPill = Math.min(distance, this.minPacmanDistancePPill);
		}

		try {
			for (GHOST ghostType : GHOST.values()) {
				int ghostNode = game.getGhostCurrentNodeIndex(ghostType);
				int distanceGhostToPacman = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), ghostNode,
						game.getPacmanLastMoveMade());
				if (distanceGhostToPacman < thresold) {
					this.nearestGhost = ghostType;
				}
			}
		} catch (IndexOutOfBoundsException ex) {
		}
		
		if(this.nearestGhost != null)
			this.nearestGhostEdibleTime = this.game.getGhostEdibleTime(this.nearestGhost);
		else
			this.nearestGhostEdibleTime = 1000;
		
		this.PacManInJunction = this.game.isJunction(this.game.getPacmanCurrentNodeIndex());
	}

	public boolean isBLINKYedible() {
		return BLINKYedible;
	}

	public boolean isINKYedible() {
		return INKYedible;
	}

	public boolean isPINKYedible() {
		return PINKYedible;
	}

	public boolean isSUEedible() {
		return SUEedible;
	}

	public double getMinPacmanDistancePPill() {
		return minPacmanDistancePPill;
	}

	public GHOST getNearestGhost() {
		return nearestGhost;
	}

	public void setNearestGhost(GHOST nearestGhost) {
		this.nearestGhost = nearestGhost;
	}

	public int getNearestGhostEdibleTime() {
		return nearestGhostEdibleTime;
	}

	public void setNearestGhostEdibleTime(int nearestGhostEdibleTime) {
		this.nearestGhostEdibleTime = nearestGhostEdibleTime;
	}

	public boolean isPacManInJunction() {
		return PacManInJunction;
	}

	public void setPacManInJunction(boolean pacManInJunction) {
		PacManInJunction = pacManInJunction;
	}

}
