package es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions;

import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.MsPacManInput;
import es.ucm.fdi.ici.fsm.Input;
import es.ucm.fdi.ici.fsm.Transition;

public class LessTimeToEatGhosts implements Transition{
	
	public static final int TIME = 30;

	@Override
	public boolean evaluate(Input in) {
		MsPacManInput input = (MsPacManInput) in;
		return input.getNearestGhostEdibleTime() < TIME || 
				(!input.isBLINKYedible() && !input.isINKYedible() && !input.isPINKYedible() && !input.isSUEedible());
	}

}
