package es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions;

public class AtLeastOneGhostEdiblePillTransition extends AtLeastOneGhostEdibleTransition{

}
