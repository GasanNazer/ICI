package es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions;

import es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.GhostsInput;
import es.ucm.fdi.ici.fsm.Input;
import es.ucm.fdi.ici.fsm.Transition;
import pacman.game.Constants.GHOST;

public class GhostEndOfEdible implements Transition{
	
	private final static int GHOST_EATABLE_TIME_LIMIT = 30;//30; 7 place
	private final static int DISTANCE_TO_PACMAN = 100;
	
	GHOST ghost;
	public GhostEndOfEdible(GHOST ghost) {
		super();
		this.ghost = ghost;
	}
	
	@Override
	public boolean evaluate(Input in) {
		GhostsInput input = (GhostsInput)in;
		int ghostTime = input.getGhostEdibleTime(ghost);
		int distanceToPacman = input.getDistanceToPacman(ghost);
		return ghostTime < GHOST_EATABLE_TIME_LIMIT && distanceToPacman < DISTANCE_TO_PACMAN;
	}

	
	@Override
	public String toString() {
		return "Ghost is close to not being edible";
	}
}
