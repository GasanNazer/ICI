package es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions;

import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.MsPacManInput;
import es.ucm.fdi.ici.fsm.Input;
import es.ucm.fdi.ici.fsm.Transition;

public class PacManNearGhostTransition implements Transition {

	public static double thresold = 30;
	
	public PacManNearGhostTransition() {
		super();
	}


	@Override
	public boolean evaluate(Input in) {
		MsPacManInput input = (MsPacManInput) in;
		return input.getNearestGhost() != null;
	}


	@Override
	public String toString() {
		return "MsPacman near Ghost";
	}

	
	
}
