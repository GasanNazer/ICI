package es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.actions;

import es.ucm.fdi.ici.fsm.Action;
import pacman.game.Game;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class ChaseAction implements Action {
	
	GHOST ghost;
	public ChaseAction(GHOST ghost) {
		this.ghost =ghost;
	}

	@Override
	public MOVE execute(Game game) {
		if (game.doesGhostRequireAction(ghost)){
			
			int pill = getClosestPPillToPacman(game);
			
			if(ghost.equals(GHOST.INKY) && pill != -1) {
				return game.getNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghost), game.getPowerPillIndex(pill), game.getGhostLastMoveMade(ghost), DM.PATH);
			}
			
			if(ghost.equals(GHOST.BLINKY)) {
				return blinkyChase(game);
			}
			if(ghost.equals(GHOST.PINKY))
				pinkyChase(game);
			
			return game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghost),
                    game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghost), DM.MANHATTAN);
		
		}
        return MOVE.NEUTRAL;
	} 
	
	private MOVE pinkyChase(Game game) {
		return game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghost),
				game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghost), DM.PATH);
	}
	
	private MOVE blinkyChase(Game game) {
		return game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghost),
				game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghost), DM.EUCLID);
	}
	
	private int getClosestPPillToPacman(Game game) {
		int distanceMin = Integer.MAX_VALUE;
		int index = -1;
		for(int p : game.getActivePowerPillsIndices()) {
			int dist = game.getShortestPathDistance(game.getGhostCurrentNodeIndex(ghost), game.getPowerPillIndex(p), game.getGhostLastMoveMade(ghost));
			if(dist < distanceMin) {
				distanceMin = dist;
				index = p;
			}
		}
		return index;
	}

}
