package es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.actions;

import es.ucm.fdi.ici.fsm.Action;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

public class ContinueRunningInTheSameDirection implements Action{

	@Override
	public MOVE execute(Game game) {
		return game.getPacmanLastMoveMade();
	}

}
