package es.ucm.fdi.ici.c2021.practica2.grupo06.ghosts.transitions;

import es.ucm.fdi.ici.fsm.Input;
import es.ucm.fdi.ici.fsm.Transition;
import pacman.game.Constants.GHOST;

public class DeadPacmanTransition implements Transition{
	
	GHOST ghost;
	public DeadPacmanTransition(GHOST ghost) {
		super();
		this.ghost = ghost;
	}
	@Override
	public boolean evaluate(Input in) {
		return in.getGame().wasPacManEaten();
	}

}
