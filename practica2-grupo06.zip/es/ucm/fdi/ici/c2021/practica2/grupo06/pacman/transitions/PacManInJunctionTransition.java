package es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.transitions;

import java.util.HashSet;

import es.ucm.fdi.ici.c2021.practica2.grupo06.pacman.MsPacManInput;
import es.ucm.fdi.ici.fsm.Input;
import es.ucm.fdi.ici.fsm.Transition;
import pacman.game.Game;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class PacManInJunctionTransition implements Transition{
	private static int limit = 30;

	@Override
	public boolean evaluate(Input in) {
		MsPacManInput input = (MsPacManInput) in;
		
		return input.isPacManInJunction() && getNearestChasingGhost(input.getGame()) != null && !getForbiddenMoves(input.getGame()).contains(input.getGame().getPacmanLastMoveMade());
	}
	
	
	private GHOST getNearestChasingGhost(Game game) {
		int pacManNode = game.getPacmanCurrentNodeIndex();
		GHOST nearestGhost = null;

		for (GHOST ghostType : GHOST.values()) {
			if (game.getGhostEdibleTime(ghostType) < 50 && game.getGhostLairTime(ghostType) == 0
					&& !game.isGhostEdible(ghostType)) {
				int ghostNode = game.getGhostCurrentNodeIndex(ghostType);
				if (game.getShortestPathDistance(pacManNode, ghostNode, game.getPacmanLastMoveMade()) < limit) {
					nearestGhost = ghostType;
				}
			}
		}

		return nearestGhost;
	}
	
	private HashSet<MOVE> getForbiddenMoves(Game game){
		HashSet<MOVE> forbiddenMoves = new HashSet<>();
		for(GHOST ghost : GHOST.values())
			if(game.getGhostLairTime(ghost) <= 0)
				forbiddenMoves.add(game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghost), game.getPacmanLastMoveMade(), DM.PATH));
		return forbiddenMoves;
	}
}
