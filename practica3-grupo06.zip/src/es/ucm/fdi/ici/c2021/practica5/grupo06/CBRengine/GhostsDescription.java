package es.ucm.fdi.ici.c2021.practica5.grupo06.CBRengine;

import java.util.HashMap;

import es.ucm.fdi.gaia.jcolibri.cbrcore.Attribute;
import es.ucm.fdi.gaia.jcolibri.cbrcore.CaseComponent;
import pacman.game.Constants.GHOST;

public class GhostsDescription implements CaseComponent {

	Integer id;
	
	HashMap<GHOST, Integer> distanceToNearestPowerPill;
	HashMap<GHOST, Integer> positionOfNearestPowerPill;
	HashMap<GHOST, Integer> distanceToPacman;
	HashMap<GHOST, Boolean> ghostEdible;
	Integer distanceToNearestPowerPillPacMan;
	Integer positionOfNearestPowerPillPacMan;
	GHOST nearestGhostToPacMan;
	Integer distanceNearestGhostToPacMan;
	HashMap<GHOST, Integer> distanceToNearestGhost;
	HashMap<GHOST, Integer> positionOfNearestGhost;
	HashMap<GHOST, GHOST> nearestGhost;
	HashMap<GHOST, Integer> distanceToNearestEdibleGhost;
	HashMap<GHOST, Integer> positionOfNearestEdibleGhost;
	HashMap<GHOST, GHOST> nearestEdibleGhost;
	HashMap<GHOST, Integer> distanceToNearestNoEdibleGhost;
	HashMap<GHOST, Integer> positionOfNearestNoEdibleGhost;
	HashMap<GHOST, GHOST> nearestNoEdibleGhost;
	// if the value is -1 the ghost is not edible
	HashMap<GHOST, Integer> edibleTimeLeft;
	// left-0,right-1, up-2, down-3
	HashMap<GHOST, Integer> directionLastMove;
	Integer numberOfPowerPillsLeft;
	Integer score;
	Integer time;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public HashMap<GHOST, Integer> getDistanceToNearestPowerPill() {
		return distanceToNearestPowerPill;
	}

	public void setDistanceToNearestPowerPill(HashMap<GHOST, Integer> distanceToNearestPowerPill) {
		this.distanceToNearestPowerPill = distanceToNearestPowerPill;
	}

	public HashMap<GHOST, Integer> getPositionOfNearestPowerPill() {
		return positionOfNearestPowerPill;
	}

	public void setPositionOfNearestPowerPill(HashMap<GHOST, Integer> positionOfNearestPowerPill) {
		this.positionOfNearestPowerPill = positionOfNearestPowerPill;
	}

	public HashMap<GHOST, Integer> getDistanceToPacman() {
		return distanceToPacman;
	}

	public void setDistanceToPacman(HashMap<GHOST, Integer> distanceToPacman) {
		this.distanceToPacman = distanceToPacman;
	}

	public HashMap<GHOST, Boolean> getGhostEdible() {
		return ghostEdible;
	}

	public void setGhostEdible(HashMap<GHOST, Boolean> ghostEdible) {
		this.ghostEdible = ghostEdible;
	}

	public Integer getDistanceToNearestPowerPillPacMan() {
		return distanceToNearestPowerPillPacMan;
	}

	public void setDistanceToNearestPowerPillPacMan(Integer distanceToNearestPowerPillPacMan) {
		this.distanceToNearestPowerPillPacMan = distanceToNearestPowerPillPacMan;
	}

	public Integer getPositionOfNearestPowerPillPacMan() {
		return positionOfNearestPowerPillPacMan;
	}

	public void setPositionOfNearestPowerPillPacMan(Integer positionOfNearestPowerPillPacMan) {
		this.positionOfNearestPowerPillPacMan = positionOfNearestPowerPillPacMan;
	}

	public GHOST getNearestGhostToPacMan() {
		return nearestGhostToPacMan;
	}

	public void setNearestGhostToPacMan(GHOST nearestGhostToPacMan) {
		this.nearestGhostToPacMan = nearestGhostToPacMan;
	}

	public Integer getDistanceNearestGhostToPacMan() {
		return distanceNearestGhostToPacMan;
	}

	public void setDistanceNearestGhostToPacMan(Integer distanceNearestGhostToPacMan) {
		this.distanceNearestGhostToPacMan = distanceNearestGhostToPacMan;
	}

	public HashMap<GHOST, Integer> getDistanceToNearestGhost() {
		return distanceToNearestGhost;
	}

	public void setDistanceToNearestGhost(HashMap<GHOST, Integer> distanceToNearestGhost) {
		this.distanceToNearestGhost = distanceToNearestGhost;
	}

	public HashMap<GHOST, Integer> getPositionOfNearestGhost() {
		return positionOfNearestGhost;
	}

	public void setPositionOfNearestGhost(HashMap<GHOST, Integer> positionOfNearestGhost) {
		this.positionOfNearestGhost = positionOfNearestGhost;
	}

	public HashMap<GHOST, GHOST> getNearestGhost() {
		return nearestGhost;
	}

	public void setNearestGhost(HashMap<GHOST, GHOST> nearestGhost) {
		this.nearestGhost = nearestGhost;
	}

	public HashMap<GHOST, Integer> getDistanceToNearestEdibleGhost() {
		return distanceToNearestEdibleGhost;
	}

	public void setDistanceToNearestEdibleGhost(HashMap<GHOST, Integer> distanceToNearestEdibleGhost) {
		this.distanceToNearestEdibleGhost = distanceToNearestEdibleGhost;
	}

	public HashMap<GHOST, Integer> getPositionOfNearestEdibleGhost() {
		return positionOfNearestEdibleGhost;
	}

	public void setPositionOfNearestEdibleGhost(HashMap<GHOST, Integer> positionOfNearestEdibleGhost) {
		this.positionOfNearestEdibleGhost = positionOfNearestEdibleGhost;
	}

	public HashMap<GHOST, GHOST> getNearestEdibleGhost() {
		return nearestEdibleGhost;
	}

	public void setNearestEdibleGhost(HashMap<GHOST, GHOST> nearestEdibleGhost) {
		this.nearestEdibleGhost = nearestEdibleGhost;
	}

	public HashMap<GHOST, Integer> getEdibleTimeLeft() {
		return edibleTimeLeft;
	}

	public void setEdibleTimeLeft(HashMap<GHOST, Integer> edibleTimeLeft) {
		this.edibleTimeLeft = edibleTimeLeft;
	}

	public HashMap<GHOST, Integer> getDirectionLastMove() {
		return directionLastMove;
	}

	public void setDirectionLastMove(HashMap<GHOST, Integer> directionLastMove) {
		this.directionLastMove = directionLastMove;
	}

	public Integer getNumberOfPowerPillsLeft() {
		return numberOfPowerPillsLeft;
	}

	public void setNumberOfPowerPillsLeft(Integer numberOfPowerPillsLeft) {
		this.numberOfPowerPillsLeft = numberOfPowerPillsLeft;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}
	
	public HashMap<GHOST, Integer> getDistanceToNearestNoEdibleGhost() {
		return distanceToNearestNoEdibleGhost;
	}

	public void setDistanceToNearestNoEdibleGhost(HashMap<GHOST, Integer> distanceToNearestNoEdibleGhost) {
		this.distanceToNearestNoEdibleGhost = distanceToNearestNoEdibleGhost;
	}

	public HashMap<GHOST, Integer> getPositionOfNearestNoEdibleGhost() {
		return positionOfNearestNoEdibleGhost;
	}

	public void setPositionOfNearestNoEdibleGhost(HashMap<GHOST, Integer> positionOfNearestNoEdibleGhost) {
		this.positionOfNearestNoEdibleGhost = positionOfNearestNoEdibleGhost;
	}

	public HashMap<GHOST, GHOST> getNearestNoEdibleGhost() {
		return nearestNoEdibleGhost;
	}

	public void setNearestNoEdibleGhost(HashMap<GHOST, GHOST> nearestNoEdibleGhost) {
		this.nearestNoEdibleGhost = nearestNoEdibleGhost;
	}

	@Override
	public Attribute getIdAttribute() {
		return new Attribute("id", GhostsDescription.class);
	}

	@Override
	public String toString() {
		return "GhostsDescription [id=" + id + ", distanceToNearestPowerPill=" + distanceToNearestPowerPill
				+ ", positionOfNearestPowerPill=" + positionOfNearestPowerPill + ", distanceToPacman="
				+ distanceToPacman + ", ghostEdible=" + ghostEdible + ", distanceToNearestPowerPillPacMan="
				+ distanceToNearestPowerPillPacMan + ", positionOfNearestPowerPillPacMan="
				+ positionOfNearestPowerPillPacMan + ", nearestGhostToPacMan=" + nearestGhostToPacMan
				+ ", distanceNearestGhostToPacMan=" + distanceNearestGhostToPacMan + ", distanceToNearestGhost="
				+ distanceToNearestGhost + ", positionOfNearestGhost=" + positionOfNearestGhost + ", nearestGhost="
				+ nearestGhost + ", distanceToNearestEdibleGhost=" + distanceToNearestEdibleGhost
				+ ", positionOfNearestEdibleGhost=" + positionOfNearestEdibleGhost + ", nearestEdibleGhost="
				+ nearestEdibleGhost + ", distanceToNearestNoEdibleGhost=" + distanceToNearestNoEdibleGhost
				+ ", positionOfNearestNoEdibleGhost=" + positionOfNearestNoEdibleGhost + ", nearestNoEdibleGhost="
				+ nearestNoEdibleGhost + ", edibleTimeLeft=" + edibleTimeLeft + ", directionLastMove="
				+ directionLastMove + ", numberOfPowerPillsLeft=" + numberOfPowerPillsLeft + ", score=" + score
				+ ", time=" + time + "]";
	}

}
