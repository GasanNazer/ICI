We haven't implemented:
- KNN majority voting
- memory optimization
- more relevant actions and choosing an action in case of there is no similar data 
- better comparison of the cases(their attibutes and similarity function)
- Ghosts-> more complicated result(currently using only score), and integration of all commented attributes(represented with HashMaps)